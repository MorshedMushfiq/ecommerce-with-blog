<x-frontheader />


<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Distinctio perspiciatis nisi maiores aspernatur odit quaerat? Aut esse quisquam dolores voluptatum! Hic, impedit? Vero.</p>

    <h1 class='text-center bg-dark text-light p-3 my-2'>{{$msg}}</h1>




    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure debitis, eum laborum possimus corrupti obcaecati ea repellat. Ullam a eius, aliquid aspernatur obcaecati, earum rem quos labore velit voluptate illum!</p>

    <a class='btn btn-success' href="{{route('cake.index')}}">Back to home</a>



<x-frontfooter />