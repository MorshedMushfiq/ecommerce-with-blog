<?php if (isset($component)) { $__componentOriginal8bb3c1087906323de6320ef660b07045 = $component; } ?>
<?php $component = App\View\Components\Frontheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb3c1087906323de6320ef660b07045)): ?>
<?php $component = $__componentOriginal8bb3c1087906323de6320ef660b07045; ?>
<?php unset($__componentOriginal8bb3c1087906323de6320ef660b07045); ?>
<?php endif; ?>


  <!-- login Section Begin -->
  <section class="contact spad">
    <div class="container">
        <div class="section-title">
            <h2 class='text-center text-light'>Sign in For Your Dashboard</h2>
            <p>Sign in now!!!</p>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-6 mx-auto">
                <div class="msg">
                    <?php if(Session::has("success")): ?>
                    <p class='alert alert-success'><?php echo e(Session::get('success')); ?></p>
                    <?php endif; ?>
                    <?php if(Session::has("error")): ?>
                    <p class='alert alert-danger'><?php echo e(Session::get('error')); ?></p>
                    <?php endif; ?>
                </div>
                <div class="contact__form">
                    <form action="<?php echo e(URL::to('/login_user')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <input type="text" name='email' placeholder="E-mail" require>
                            </div>
                            <div class="col-lg-12">
                                <input type="password" name='password' placeholder='Password' require>
                                <button type="submit" class="site-btn">Sign In</button>
                            </div>
                            <a href="<?php echo e(URL::to('google/login')); ?>">
                                <img src="<?php echo e(URL::asset('googlesignin.png')); ?>" style='height: 120px;' alt="">
                            </a>

                        </div>
                        <p>Don't have any account? Click here for <a href="<?php echo e(URL::to('/register')); ?>">Register</a></p>
                    </form>
                </div>
            </div>

        </div>






    </div>
</section>
<!-- login Section End -->



<?php if (isset($component)) { $__componentOriginal392e6e19c5f90d19702799112f9c5d2c = $component; } ?>
<?php $component = App\View\Components\Frontfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c)): ?>
<?php $component = $__componentOriginal392e6e19c5f90d19702799112f9c5d2c; ?>
<?php unset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c); ?>
<?php endif; ?><?php /**PATH F:\xampp\htdocs\caketown\resources\views/login.blade.php ENDPATH**/ ?>