<div id="comment_section">
    
    <?php if (isset($component)) { $__componentOriginal8bb3c1087906323de6320ef660b07045 = $component; } ?>
<?php $component = App\View\Components\Frontheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb3c1087906323de6320ef660b07045)): ?>
<?php $component = $__componentOriginal8bb3c1087906323de6320ef660b07045; ?>
<?php unset($__componentOriginal8bb3c1087906323de6320ef660b07045); ?>
<?php endif; ?>


<div class="container mt-5">
    <div class="container">
        <div class="section-title position-relative text-center mx-auto mb-5 pb-3" style="max-width: 600px;">
            <h2 class="text-primary font-secondary">Our Blogs</h2>
            <h1 class="display-4 text-uppercase">CakeZone Posts</h1>
        </div>
    </div>


    <div class="d-flex justify-content-between row my-2">
        <div class="col-md-12 border border-info">
            <div class="d-flex flex-column comment-section">
                <div class="bg-white p-2">
                    <?php $__currentLoopData = $user_infos->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($single_post->user_id==$user->id): ?>
                    <div class="d-flex flex-row user-info"><img class="rounded-circle" src="<?php echo e(URL::asset('uploads/profiles/'. $user->image)); ?>" width="40">
                        <div class="d-flex flex-column justify-content-start ml-2"><span class="d-block font-weight-bold name"><?php echo e($user->name); ?></span><span class="date text-black-50">Shared publicly - <?php echo e($single_post->created_at); ?></span></div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mt-2">
                        <p class='display-4'><?php echo e($single_post->title); ?></p>
                        <p class="comment-text"><?php echo e($single_post->post_description); ?></p>
                        <img class="img-fluid" src="<?php echo e(URL::asset('uploads/posts/'.$single_post->post_image)); ?>">
                    </div>
                </div>
                <h2 class='text-success display-5'>All Comments</h2>
                <?php $__currentLoopData = $show_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($all_comments->post_id==$single_post->id): ?>
                <div class="comment">
                    
                    <div class="d-flex flex-row justify-content-start align-items-start py-2">
                        <?php $__currentLoopData = $user_infos->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($all_comments->user_id==$user->id): ?>
                        
                        <img class="rounded-circle" src="<?php echo e(URL::asset('uploads/profiles/'.$user->image )); ?>" width="40">
                        
                        <div class="second py-2 px-2 mb-1"> <span class="text1">
                            <div class="d-flex flex-column justify-content-start ml-2 mb-3"><span class="d-block font-weight-bold name"><?php echo e($user->name); ?></span><span class="date text-black-50">Shared publicly - <?php echo e($all_comments->created_at); ?></span></div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($all_comments->comment); ?>

                            
                        </span>
                        </div>
                    </div>
                 
                    <?php if($all_comments->user_id==$user->id && Auth::user()->type=="Admin"): ?>
                    
                    <a class='text-underline text-danger' href="<?php echo e(route('delete.comment', $all_comments->id)); ?>">Delete comment</a>
                    <?php endif; ?>
                 
                </div>

                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <div class="bg-light p-2">
                    <?php if(auth()->guard()->check()): ?>
                    <div class="d-flex flex-row align-items-start">
                        <img class="rounded-circle" src="<?php echo e(URL::asset('uploads/profiles/'. Auth::user()->image)); ?>" width="40">
                        <form style="width: 100%;" action="<?php echo e(url('post_comment')); ?>" method="POST" id="commentForm">
                            <?php echo csrf_field(); ?>
                            <textarea name='comment' class="form-control ml-1 shadow-none textarea"></textarea>
                    </div>

                            <input type="hidden" name="post_id" value="<?php echo e($single_post->id); ?>">
                            <div class="mt-2 text-right"><button class="btn btn-primary btn-sm shadow-none" type="submit">Post comment</button><button class="btn btn-outline-primary btn-sm ml-1 shadow-none" type="reset">Cancel</button>
                            </div>
                        </form>
                        
                </div>        
                <?php else: ?>

                <p class='mt-3 p-2'>Please <a class="fw-bold" href="<?php echo e(route('cake.login')); ?>">Login</a> or <a href="<?php echo e(route('cake.register')); ?>" class="fw-bold">Register</a> For Leaving a comment here.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<?php if (isset($component)) { $__componentOriginal392e6e19c5f90d19702799112f9c5d2c = $component; } ?>
<?php $component = App\View\Components\Frontfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c)): ?>
<?php $component = $__componentOriginal392e6e19c5f90d19702799112f9c5d2c; ?>
<?php unset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c); ?>
<?php endif; ?>

</div><?php /**PATH F:\xampp\htdocs\caketown\resources\views/single_post.blade.php ENDPATH**/ ?>