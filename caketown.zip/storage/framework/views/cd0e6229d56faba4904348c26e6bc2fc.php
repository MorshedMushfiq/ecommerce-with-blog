<?php if (isset($component)) { $__componentOriginal8bb3c1087906323de6320ef660b07045 = $component; } ?>
<?php $component = App\View\Components\Frontheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb3c1087906323de6320ef660b07045)): ?>
<?php $component = $__componentOriginal8bb3c1087906323de6320ef660b07045; ?>
<?php unset($__componentOriginal8bb3c1087906323de6320ef660b07045); ?>
<?php endif; ?>


<!-- register Section Begin -->
<section class="contact spad">
    <div class="container">
        <div class="section-title">
            <h2>Create a New Account Here</h2>
            <span>Register Now!!!</span>
        </div>
        <div class="row">
            <div class="col-lg-6 col-md-6 mx-auto">
                <div class="contact__form">
                    <form action="<?php echo e(URL::to('register_user')); ?>" method='POST' enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <input type="text" name='name' placeholder="Full Name" required>
                            </div>
                            <div class="col-lg-6">
                                <input type="text" name='email' placeholder="E-mail" required>
                            </div>
                            <div class="col-lg-12">
                                <input type="file" class='form-control' name='file' required>
                            </div>
                            <div class="col-lg-12">
                                <input type="password" name='password' placeholder='Password' required>
                                <button type="submit" class="site-btn">Register</button>
                            </div>
                        </div>
                        <p>Already have an account? Click here for <a href="<?php echo e(URL::to('/login')); ?>">Sign in</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- register Section End -->




<?php if (isset($component)) { $__componentOriginal392e6e19c5f90d19702799112f9c5d2c = $component; } ?>
<?php $component = App\View\Components\Frontfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c)): ?>
<?php $component = $__componentOriginal392e6e19c5f90d19702799112f9c5d2c; ?>
<?php unset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c); ?>
<?php endif; ?><?php /**PATH F:\xampp\htdocs\caketown\resources\views/register.blade.php ENDPATH**/ ?>