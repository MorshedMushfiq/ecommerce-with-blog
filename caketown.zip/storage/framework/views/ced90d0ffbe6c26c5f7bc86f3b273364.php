<?php if (isset($component)) { $__componentOriginal8bb3c1087906323de6320ef660b07045 = $component; } ?>
<?php $component = App\View\Components\Frontheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb3c1087906323de6320ef660b07045)): ?>
<?php $component = $__componentOriginal8bb3c1087906323de6320ef660b07045; ?>
<?php unset($__componentOriginal8bb3c1087906323de6320ef660b07045); ?>
<?php endif; ?>

<div class="container mt-5 mb-5">
    <div class="row d-flex justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <?php if(Session::has("success")): ?>
                <p class='alert alert-success'><?php echo e(Session::get('success')); ?></p>
                <?php endif; ?>
                <?php if(Session::has("error")): ?>
                <p class='alert alert-danger'><?php echo e(Session::get('error')); ?></p>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="images p-3">
                            <div class="text-center p-4"> <img id="main-image" src="<?php echo e(URL::asset('uploads/products/'. $single_product->image)); ?>" width="250" /> </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="product p-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center"> <i class="fa fa-long-arrow-left"></i> <a class="ml-1 btn btn-danger btn-danger" href="<?php echo e(route('cake.index')); ?>">Back</a> </div>
                            </div>
                            <div class="mt-4 mb-3"> <span class="text-uppercase text-muted brand">Cake Town</span>
                                <h5 class="text-uppercase"><?php echo e($single_product->title); ?></h5>
                                <div class="price d-flex flex-row align-items-center"> <span class="act-price">$<?php echo e($single_product->price); ?></span>
                                </div>
                            </div>
                            <p class="about"><?php echo e($single_product->description); ?></p>

                        


                        

                        <form action="<?php echo e(route('add.cart')); ?>" method='POST'>
                        <?php echo csrf_field(); ?>
                            

                        <div class="d-flex flex-row mb-3">
                          <a href='#' class="btn btn-link px-2"
                            onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
                            <i class="fas fa-minus"></i>
                          </a>


                            <input id="form1" name='quantity' min="1" max="<?php echo e($single_product->quantity); ?>" name="quantity" value="1" type="number" value="<?php echo e($single_product->quantity); ?>"
                            class="form-control form-control-sm" style="width: 50px;" />
      
                          <a href="#" class="btn btn-link px-2"
                            onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
                            <i class="fas fa-plus"></i>
                          </a>
                        </div>

                        <input type="hidden" name='id' value="<?php echo e($single_product->id); ?>">

                        <input type='submit' name='add_cart' class="btn btn-danger text-uppercase mr-2 px-4" value="Add to Cart">


                            

                        </div>    
                        
                      </form>
                         

                        



                </div>
            </div>
        </div>
    </div>
</div>






<?php if (isset($component)) { $__componentOriginal392e6e19c5f90d19702799112f9c5d2c = $component; } ?>
<?php $component = App\View\Components\Frontfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c)): ?>
<?php $component = $__componentOriginal392e6e19c5f90d19702799112f9c5d2c; ?>
<?php unset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c); ?>
<?php endif; ?><?php /**PATH F:\xampp\htdocs\caketown\resources\views/cart.blade.php ENDPATH**/ ?>