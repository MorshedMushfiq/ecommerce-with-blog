<?php if (isset($component)) { $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0 = $component; } ?>
<?php $component = App\View\Components\Adminheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0)): ?>
<?php $component = $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0; ?>
<?php unset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0); ?>
<?php endif; ?>
              

              <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                        <p class="card-title mb-0">Our Orders</p>
    
                        <?php if(Session::has("success")): ?>
                        <p class='alert alert-success my-2'><?php echo e(Session::get("success")); ?> <button class='close' data-dismiss="alert">&times;</button> </p>
    
                        <?php endif; ?>
                      
                      <div class="table-responsive">
                        <table style='overflow-x: visiable;' class="table table-striped table-borderless">
                          <thead>
                            <tr>
                              <th>#.</th>
                              <th>Customer</th>
                              <th>E-mail</th>
                              <th>Customer Status</th>
                              <th>Bill</th>
                              <th>Cell</th>
                              <th>Address</th>
                              <th>Order Date</th>
                              <th>Products</th>
                              <th>Order Status</th>
                              <th>Action</th>
                            </tr>  
                          </thead>
                          <tbody>
                            <?php
                                $i=0;
                            ?>

                            <?php $__currentLoopData = $all_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php
                                $i++;
                            ?>
                            <tr>
                              <td><?php echo e($i); ?></td>
                              <td><?php echo e($order->name); ?></td>
                              <td class="font-weight-bold"><?php echo e($order->email); ?></td>
                              <td class="font-weight-medium"><?php echo e($order->userStatus); ?></td>
                              <td><?php echo e($order->bill); ?></td>
                              <td><?php echo e($order->cell_number); ?></td>
                              <td><?php echo e($order->address); ?></td>
                              <td><?php echo e($order->created_at); ?></td>
                              <td>
                                <!-- Button to Open the Modal -->
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#updatemodal<?php echo e($i); ?>">
                                  Products
                                  </button>  
      
                                   <!-- The Modal -->
                          <div class="modal" id="updatemodal<?php echo e($i); ?>">
                              <div class="modal-dialog">
                                  <div class="modal-content">
                          
                                      <!-- Modal Header -->
                                      <div class="modal-header">
                                      <h4 class="modal-title">Order Products</h4>
                                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                                      </div>
                              
                                      <!-- Modal body -->
                                      <div class="modal-body">
                                          <table>
                                            <thead>
                                              <tr>
                                                <th>Product</th>
                                                <th>Image</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Sub Total</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              <?php $__currentLoopData = $order_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <?php if($order_items->orderId==$order->id): ?>
                                              <tr>
                                                <td><?php echo e($order_items->title); ?></td>
                                                <td><img src="<?php echo e(URL::to('uploads/products/'. $order_items->image)); ?>" alt=""></td>
                                                <td><?php echo e($order_items->price); ?></td>
                                                <td><?php echo e($order_items->quantites); ?></td>
                                                <td><?php echo e($order_items->price * $order_items->quantites); ?></td>
                                              </tr>
                                              <?php endif; ?>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                          </table>
                                      </div>
                          
                                  </div>
                              </div>
                          </div>
    
                              </td>
                              <td><?php echo e($order->status); ?></td>
                              <td>
                                <?php if($order->status=="Paid"): ?>
                                <a href="<?php echo e(URL::to('/dashboard/orders/Accept', $order->id)); ?>" class='btn btn-success btn-sm'>Accept</a>  
                                <a href="<?php echo e(URL::to('/dashboard/orders/Reject', $order->id)); ?>" class='btn btn-danger btn-sm'>Reject</a> 
                                <?php elseif($order->status=="Accept"): ?>
                                <a href="<?php echo e(URL::to('/dashboard/orders/Delievred', $order->id)); ?>" class='btn btn-success btn-sm'>Completed</a>
                                <?php elseif($order->status=="Delievred"): ?>
                                Already Accepted.
                                <?php else: ?>
                                <a href="<?php echo e(URL::to('/dashboard/orders/Accept', $order->id)); ?>" class='btn btn-success btn-sm'>Accept</a>
                                <?php endif; ?>
                              </td>
    
    
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
            </div>

            
<?php if (isset($component)) { $__componentOriginal26164fe4a2d780f5573d648a08b3d363 = $component; } ?>
<?php $component = App\View\Components\Adminfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26164fe4a2d780f5573d648a08b3d363)): ?>
<?php $component = $__componentOriginal26164fe4a2d780f5573d648a08b3d363; ?>
<?php unset($__componentOriginal26164fe4a2d780f5573d648a08b3d363); ?>
<?php endif; ?>



<?php /**PATH F:\xampp\htdocs\caketown\resources\views/admin/allorders.blade.php ENDPATH**/ ?>