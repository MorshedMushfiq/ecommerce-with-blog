
<?php if (isset($component)) { $__componentOriginal8bb3c1087906323de6320ef660b07045 = $component; } ?>
<?php $component = App\View\Components\Frontheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb3c1087906323de6320ef660b07045)): ?>
<?php $component = $__componentOriginal8bb3c1087906323de6320ef660b07045; ?>
<?php unset($__componentOriginal8bb3c1087906323de6320ef660b07045); ?>
<?php endif; ?>


<section class="h-100 h-custom">
    <div class="container h-100 py-5">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col">
          <?php if(Session::has("success")): ?>
          <p class='alert alert-success'><?php echo e(Session::get('success')); ?></p>
          <?php endif; ?>
          <?php if(Session::has("error")): ?>
          <p class='alert alert-danger'><?php echo e(Session::get('error')); ?></p>
          <?php endif; ?>
  
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col" class="h5">Shopping Bag</th>
                  <th scope="col">Item Name</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Price</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $total=0;
                ?>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <a href="<?php echo e(route('delete.cart', $cart->id)); ?>"><img style="width: 50px" src="<?php echo e(URL::asset('img/del.png')); ?>" alt=""></a>

                  </td>
                  <th scope="row">
                    <div class="d-flex align-items-center">
                      <img src="<?php echo e(URL::asset('uploads/products/'. $cart->image)); ?>" class="img-fluid rounded-3"
                        style="width: 120px;" alt="Book">
                      <div class="flex-column ms-4">
                        <p><?php echo e($cart->title); ?></p>
                      </div>
                    </div>
                  </th>
                  <td class="align-middle">
                    <p class="mb-0" style="font-weight: 500;"><?php echo e($cart->category); ?></p>
                  </td>
                  <td class="align-middle">
                    <form action="<?php echo e(route('update.cart')); ?>" method='POST'>
                      <?php echo csrf_field(); ?>
                      <div class="d-flex flex-row">
                        <a href='#' class="btn btn-link px-2"
                        onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
                        <i class="fas fa-minus"></i>
                      </a>
  
                      <input id="form1" min="0" max=<?php echo e($cart->pQuantites); ?> name="quantity" type="number" value="<?php echo e($cart->quantites); ?>"
                        class="form-control form-control-sm" style="width: 50px;" />
  
                      <a href="#" class="btn btn-link px-2"
                        onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
                        <i class="fas fa-plus"></i>
                      </a>
                      <input type="hidden" name='id' value="<?php echo e($cart->id); ?>">

                        <div class="form-group">
                          <input type="submit" value="Update" class='btn btn-warning btn-sm'>
                        </div>
                  </div>
                    </form>
                  </td>
                  <td class="align-middle">
                    <p class="mb-0" style="font-weight: 500;">$<?php echo e($cart->price * $cart->quantites); ?></p>
                  </td>
                </tr>
                <?php
                    $total+= ($cart->price * $cart->quantites);
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
  
          <div class="card shadow-2-strong mb-5 mb-lg-0" style="border-radius: 16px;">
            <div class="card-body p-4">
  

  
              <!-- Button to Open the Modal -->
              <button type="button" class="btn btn-primary btn-sm my-2" data-toggle="modal" data-target="#paymodel">
                Payment Via stripe
              </button>

                    <!-- The Modal -->
                    <div class="modal" id="paymodel">
                      <div class="modal-dialog">
                          <div class="modal-content">
                  
                              <!-- Modal Header -->
                              <div class="modal-header">
                              <h4 class="modal-title">Add New Product</h4>
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                      
                              <!-- Modal body -->
                              <div class="modal-body">
                                <form action="<?php echo e(URL::to('/payment-stripe')); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <div class="row">
                                    <div class="col-lg-12">
                                        <div class="">
                                          <div class="form-outline mb-4 mb-xl-5">
                                            <input type="text" name="name" id="typeName" class="form-control form-control-lg" siez="17"
                                              placeholder="John Smith" />
                                            <label class="form-label" for="typeName">Name on card</label>
                                          </div>
                      
                                          <div class="form-outline mb-4 mb-xl-5">
                                            <input type="email" name="email" id="typeExp" class="form-control form-control-lg" placeholder="E-mail"
                                              size="7" id="exp" minlength="7" required/>
                                            <label class="form-label" for="typeExp">E-mail</label>
                                          </div>
                                        </div>
                                        <div class="">
                                          <div class="form-outline mb-4 mb-xl-5">
                                            <input type="text" name="cell" id="typeText" class="form-control form-control-lg" siez="17"
                                              placeholder="+880123456789" minlength="11" maxlength="11" required/>
                                            <label class="form-label" for="typeText">Cell Number</label>
                                          </div>
                      
                                          <div class="form-outline mb-4 mb-xl-5">
                                            <input type="text" name="address" id="typeText" class="form-control form-control-lg"
                                              placeholder="Address" required/>
                                            <label class="form-label" for="typeText">Address</label>
                                          </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                      <div class="d-flex justify-content-between" style="font-weight: 500;">
                                        <p class="mb-2">Subtotal</p>
                                        <p class="mb-2">$<?php echo e($total); ?></p>
                                      </div>
                      
                                      <div class="d-flex justify-content-between" style="font-weight: 500;">
                                        <p class="mb-0">Shipping</p>
                                        <p class="mb-0">$60</p>
                                      </div>
                      
                                      <hr class="my-4">
                      
                                      <div class="d-flex justify-content-between mb-4" style="font-weight: 500;">
                                        <p class="mb-2">Total (tax included)</p>
                                        <p class="mb-2">$<?php echo e($total + 60); ?></p>
                                      </div>
                                      <input type="hidden" name='bill' value="<?php echo e($total + 60); ?>">
                  
                  
                                      
                                      

                                      <button type="submit" class="btn btn-primary btn-block btn-lg" >
                                        <div class="d-flex justify-content-between">
                                          <span>Checkout via Stripe</span>
                                          <span>$<?php echo e($total + 60); ?></span>
                                        </div>
                                      </button>
                      
                                    </div>
                                  </div>
                                </form>
                                <form action="<?php echo e(route('apply.coupon')); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <div class="form-outline mt-4 mb-4 mb-xl-5">
                                    <input type="text" name="coupon" id="typeText" class="form-control form-control-lg"
                                      placeholder="Apply Coupon" required/>

                                    <input type="submit" class="btn btn-warning btn-block mt-3" value='Apply coupon'>
                                  </div>
                                </form>
                              </div>
                  
                          </div>
                      </div>
                    </div>



                    

              <!-- Button to Open the Modal -->
              <button type="button" class="btn btn-warning btn-sm my-2" data-toggle="modal" data-target="#sslmodel">
                Payment Via Paypal
              </button>

                    <!-- The Modal -->
                    <div class="modal" id="sslmodel">
                      <div class="modal-dialog">
                          <div class="modal-content">
                  
                              <!-- Modal Header -->
                              <div class="modal-header">
                              <h4 class="modal-title">Payment Via Paypal</h4>
                              <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                      
                              <!-- Modal body -->
                              <div class="modal-body">
                                <div class="col-lg-12">
                                  <form action="<?php echo e(route('apply.coupon')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-outline mb-4 mb-xl-5">
                                      <input type="text" name="coupon" id="typeText" class="form-control form-control-lg"
                                        placeholder="Apply Coupon"/>
  
                                        <input type="submit" class="btn btn-warning btn-block mt-3" value='Apply coupon'>
                                    </div>
                                  </form>
                                  <div class="d-flex justify-content-between" style="font-weight: 500;">
                                    <p class="mb-2">Subtotal</p>
                                    
                                    <p class="mb-2">$<?php echo e($total); ?></p>
                                    
                                  </div>
                  
                                  <div class="d-flex justify-content-between" style="font-weight: 500;">
                                    <p class="mb-0">Shipping</p>
                                    <p class="mb-0">$60</p>
                                  </div>
                  
                                  <hr class="my-4">
                  
                                  <div class="d-flex justify-content-between mb-4" style="font-weight: 500;">
                                    <p class="mb-2">Total (tax included)</p>
                                    <p class="mb-2">$<?php echo e($total + 60); ?></p>
                                  </div>
                                  <form action="<?php echo e(route('request.paypal')); ?>" method="POST">
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name='bill' value="<?php echo e($total + 60); ?>">
              
              
                                  
                                  
                  
                                  <button type='submit' class="btn btn-primary btn-block btn-lg" >
                                    <div class="d-flex justify-content-between">
                                      <span>Checkout via Paypal</span>
                                      <span>$<?php echo e($total + 60); ?></span>
                                    </div>
                                  </button>
                                  </form>
                  
                                </div>
                              </div>
                  
                          </div>
                      </div>
                    </div>












            </div>
          </div>
  
        </div>
      </div>
    </div>
  </section>

  <?php if (isset($component)) { $__componentOriginal392e6e19c5f90d19702799112f9c5d2c = $component; } ?>
<?php $component = App\View\Components\Frontfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c)): ?>
<?php $component = $__componentOriginal392e6e19c5f90d19702799112f9c5d2c; ?>
<?php unset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c); ?>
<?php endif; ?><?php /**PATH F:\xampp\htdocs\caketown\resources\views/shopping_cart.blade.php ENDPATH**/ ?>