<?php if (isset($component)) { $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0 = $component; } ?>
<?php $component = App\View\Components\Adminheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Trash Data']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0)): ?>
<?php $component = $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0; ?>
<?php unset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0); ?>
<?php endif; ?>
      <div class="main-panel">
        <div class="content-wrapper">

          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <a class='btn btn-warning btn-sm my-2' href="<?php echo e(route('team.page')); ?>">Back</a>
                    <p class="card-title mb-0">Trash Team</p>
                    <?php if(Session::has("success")): ?>
                    <p class='alert alert-success my-2'><?php echo e(Session::get("success")); ?> <button class='close' data-dismiss="alert">&times;</button> </p>

                    <?php endif; ?>
                  

                  <div class="table-responsive">
                    <table class="table table-striped table-borderless">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Image</th>
                          <th>Role</th>
                          <th>Cell</th>
                          <th>Action</th>
                        </tr>  
                      </thead>
                      <tbody>
                        <?php
                            $i=0;
                        ?>
                        <?php $__currentLoopData = $all_trash_team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trash_team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i++;
                        ?>
                        <tr>
                          <td><?php echo e($i); ?></td>
                          <td><?php echo e($trash_team->name); ?></td>
                          <td><img src="<?php echo e(URL::asset('uploads/teams/'.$trash_team->image)); ?>" alt=""></td>
                          <td class="font-weight-bold">$<?php echo e($trash_team->role); ?></td>
                          <td class="font-weight-medium"><?php echo e($trash_team->cell); ?><td>
                            <a href="<?php echo e(route('team.restore', $trash_team->id)); ?>" class='btn btn-warning btn-sm'>Restore</a>
                            <a href="<?php echo e(route('team.delete', $trash_team->id)); ?>" class='btn btn-danger btn-sm'>Delete Permanently</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->


<?php if (isset($component)) { $__componentOriginal26164fe4a2d780f5573d648a08b3d363 = $component; } ?>
<?php $component = App\View\Components\Adminfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26164fe4a2d780f5573d648a08b3d363)): ?>
<?php $component = $__componentOriginal26164fe4a2d780f5573d648a08b3d363; ?>
<?php unset($__componentOriginal26164fe4a2d780f5573d648a08b3d363); ?>
<?php endif; ?>

<?php /**PATH F:\xampp\htdocs\caketown\resources\views/admin/team_trash.blade.php ENDPATH**/ ?>