<?php if (isset($component)) { $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0 = $component; } ?>
<?php $component = App\View\Components\Adminheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Account Informations']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0)): ?>
<?php $component = $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0; ?>
<?php unset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0); ?>
<?php endif; ?>
      <div class="main-panel">
        <div class="content-wrapper">

          <div class="row">
            <div class="col-12 col-md-6 col-lg-6 mx-auto grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                    <p class="card-title mb-0">My Profile</p>
                    <p class="card-title mb-0"><?php echo e($user->name); ?>(<?php echo e($user->type); ?>)</p>
                    <div class="contact__form">
                        <div class="msg">
                            <?php if(Session::has("success")): ?>
                            <p class='alert alert-success'><?php echo e(Session::get('success')); ?></p>
                            <?php endif; ?>
                            <?php if(Session::has("error")): ?>
                            <p class='alert alert-danger'><?php echo e(Session::get('error')); ?></p>
                            <?php endif; ?>
                        </div>
                        <img class='d-block' style='width: 200px; padding: 20px; margin: 0px auto;' src="<?php echo e(URL::asset('uploads/profiles/' . $user->image)); ?>" alt="">
                        <form action="<?php echo e(route('profile.update')); ?>" method='POST' enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <input type="text" class='form-control mb-2' name='name' placeholder="Full Name" value="<?php echo e($user->name); ?>" required>
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" name='email' placeholder="E-mail" class='form-control mb-2' value="<?php echo e($user->email); ?>" readonly required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="file" class='form-control mb-2' name='file' required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="text" value="<?php echo e($user->password); ?>" name='password' class='form-control mb-2' placeholder='Password' required>
                                    <button type="submit" class="btn btn-primary btn-sm">Save Changes</button>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
              </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->


<?php if (isset($component)) { $__componentOriginal26164fe4a2d780f5573d648a08b3d363 = $component; } ?>
<?php $component = App\View\Components\Adminfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26164fe4a2d780f5573d648a08b3d363)): ?>
<?php $component = $__componentOriginal26164fe4a2d780f5573d648a08b3d363; ?>
<?php unset($__componentOriginal26164fe4a2d780f5573d648a08b3d363); ?>
<?php endif; ?>

<?php /**PATH F:\xampp\htdocs\caketown\resources\views/profile.blade.php ENDPATH**/ ?>