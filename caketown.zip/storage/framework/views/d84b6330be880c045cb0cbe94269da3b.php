<?php if (isset($component)) { $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0 = $component; } ?>
<?php $component = App\View\Components\Adminheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Trash Data']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0)): ?>
<?php $component = $__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0; ?>
<?php unset($__componentOriginal6ca5b0a33bde3b81990bf21f2bb93ba0); ?>
<?php endif; ?>
      <div class="main-panel">
        <div class="content-wrapper">

          <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <a class='btn btn-warning btn-sm my-2' href="<?php echo e(route('admin.product')); ?>">Back</a>
                    <p class="card-title mb-0">Trash Products</p>
                    <?php if(Session::has("success")): ?>
                    <p class='alert alert-success my-2'><?php echo e(Session::get("success")); ?> <button class='close' data-dismiss="alert">&times;</button> </p>

                    <?php endif; ?>
                  

                  <div class="table-responsive">
                    <table class="table table-striped table-borderless">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Image</th>
                          <th>Price</th>
                          <th>Quantity</th>
                          <th>Category</th>
                          <th>Type</th>
                          <th>Action</th>
                        </tr>  
                      </thead>
                      <tbody>
                        <?php
                            $i=0;
                        ?>
                        <?php $__currentLoopData = $all_trash_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trash_products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $i++;
                        ?>
                        <tr>
                          <td><?php echo e($trash_products->title); ?></td>
                          <td><img src="<?php echo e(URL::asset('/storage/uploads/products/'.$trash_products->image)); ?>" alt=""></td>
                          <td class="font-weight-bold">$<?php echo e($trash_products->price); ?></td>
                          <td class="font-weight-medium"><?php echo e($trash_products->quantites); ?></td>
                          <td class="font-weight-medium"><div class="badge badge-success"><?php echo e($trash_products->category); ?></div></td>
                          <td class="font-weight-medium"><div class="badge badge-warning"><?php echo e($trash_products->type); ?></div></td>
                          <td>
                            <a href="<?php echo e(route('products.restore', $trash_products->id)); ?>" class='btn btn-warning btn-sm'>Restore</a>
                            <a href="<?php echo e(route('products.delete', $trash_products->id)); ?>" class='btn btn-danger btn-sm'>Delete Permanently</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->


<?php if (isset($component)) { $__componentOriginal26164fe4a2d780f5573d648a08b3d363 = $component; } ?>
<?php $component = App\View\Components\Adminfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Adminfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal26164fe4a2d780f5573d648a08b3d363)): ?>
<?php $component = $__componentOriginal26164fe4a2d780f5573d648a08b3d363; ?>
<?php unset($__componentOriginal26164fe4a2d780f5573d648a08b3d363); ?>
<?php endif; ?>

<?php /**PATH F:\xampp\htdocs\caketown\resources\views/admin/trash.blade.php ENDPATH**/ ?>