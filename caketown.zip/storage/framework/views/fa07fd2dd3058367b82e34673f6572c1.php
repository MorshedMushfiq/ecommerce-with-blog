
<?php if (isset($component)) { $__componentOriginal8bb3c1087906323de6320ef660b07045 = $component; } ?>
<?php $component = App\View\Components\Frontheader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontheader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8bb3c1087906323de6320ef660b07045)): ?>
<?php $component = $__componentOriginal8bb3c1087906323de6320ef660b07045; ?>
<?php unset($__componentOriginal8bb3c1087906323de6320ef660b07045); ?>
<?php endif; ?>


<section class="h-100 h-custom">
    <div class="container h-100 py-5">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col">
  
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col" class="h5">Shopping Bag</th>
                  <th scope="col">Item Name</th>
                  <th scope="col">Quantity</th>
                  <th scope="col">Price</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <a href="#"><img style="width: 50px" src="<?php echo e(URL::asset('img/del.png')); ?>" alt=""></a>

                  </td>
                  <th scope="row">
                    <div class="d-flex align-items-center">
                      <img src="<?php echo e(URL::asset('uploads/products/'. $single_product->image)); ?>" class="img-fluid rounded-3"
                        style="width: 120px;" alt="Book">
                      <div class="flex-column ms-4">
                        <p><?php echo e($single_product->title); ?></p>
                      </div>
                    </div>
                  </th>
                  <td class="align-middle">
                    <p class="mb-0" style="font-weight: 500;"><?php echo e($single_product->category); ?></p>
                  </td>
                  <td class="align-middle">
                    <form action="">
                      <div class="d-flex flex-row">
                        <a href='#' class="btn btn-link px-2"
                        onclick="this.parentNode.querySelector('input[type=number]').stepDown()">
                        <i class="fas fa-minus"></i>
                      </a>
  
                      <input id="form1" min="0" max="<?php echo e($single_product->quantity); ?>" name="quantity" value="1" type="number" value="<?php echo e($single_product->quantity); ?>"
                        class="form-control form-control-sm" style="width: 50px;" />
  
                      <a href="#" class="btn btn-link px-2"
                        onclick="this.parentNode.querySelector('input[type=number]').stepUp()">
                        <i class="fas fa-plus"></i>
                      </a>

                        <div class="form-group">
                          <input type="submit" value="Update" class='btn btn-warning btn-sm'>
                        </div>
                  </div>
                    </form>
                  </td>
                  <td class="align-middle">
                    <p class="mb-0" style="font-weight: 500;">$<?php echo e($single_product->price); ?></p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
  
          <div class="card shadow-2-strong mb-5 mb-lg-0" style="border-radius: 16px;">
            <div class="card-body p-4">
  
              <div class="row">
                <div class="col-md-6 col-lg-6 col-xl-6">
                  <div class="row">
                    <div class="col-12 col-xl-6">
                      <div class="form-outline mb-4 mb-xl-5">
                        <input type="text" name="name" id="typeName" class="form-control form-control-lg" siez="17"
                          placeholder="John Smith" />
                        <label class="form-label" for="typeName">Name on card</label>
                      </div>
  
                      <div class="form-outline mb-4 mb-xl-5">
                        <input type="email" name="email" id="typeExp" class="form-control form-control-lg" placeholder="E-mail"
                          size="7" id="exp" minlength="7" maxlength="7" />
                        <label class="form-label" for="typeExp">E-mail</label>
                      </div>
                    </div>
                    <div class="col-12 col-xl-6">
                      <div class="form-outline mb-4 mb-xl-5">
                        <input type="text" name="cell" id="typeText" class="form-control form-control-lg" siez="17"
                          placeholder="+880123456789" minlength="11" maxlength="11" />
                        <label class="form-label" for="typeText">Cell Number</label>
                      </div>
  
                      <div class="form-outline mb-4 mb-xl-5">
                        <input type="text" name="address" id="typeText" class="form-control form-control-lg"
                          placeholder="Address"/>
                        <label class="form-label" for="typeText">Address</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-6 col-xl-6">
                  <div class="d-flex justify-content-between" style="font-weight: 500;">
                    <p class="mb-2">Subtotal</p>
                    <p class="mb-2">$<?php echo e($single_product->price); ?></p>
                  </div>
  
                  <div class="d-flex justify-content-between" style="font-weight: 500;">
                    <p class="mb-0">Shipping</p>
                    <p class="mb-0">$</p>
                  </div>
  
                  <hr class="my-4">
  
                  <div class="d-flex justify-content-between mb-4" style="font-weight: 500;">
                    <p class="mb-2">Total (tax included)</p>
                    <p class="mb-2">$</p>
                  </div>
  
                  <button type="submit" class="btn btn-primary btn-block btn-lg">
                    <div class="d-flex justify-content-between">
                      <span>Checkout</span>
                      <span>$</span>
                    </div>
                  </button>
  
                </div>
              </div>
  
            </div>
          </div>
  
        </div>
      </div>
    </div>
  </section>

  <?php if (isset($component)) { $__componentOriginal392e6e19c5f90d19702799112f9c5d2c = $component; } ?>
<?php $component = App\View\Components\Frontfooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontfooter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Frontfooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c)): ?>
<?php $component = $__componentOriginal392e6e19c5f90d19702799112f9c5d2c; ?>
<?php unset($__componentOriginal392e6e19c5f90d19702799112f9c5d2c); ?>
<?php endif; ?><?php /**PATH F:\xampp\htdocs\caketown\resources\views/price.blade.php ENDPATH**/ ?>